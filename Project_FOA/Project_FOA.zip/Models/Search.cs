﻿using Project_FOA.Models.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Tweetinvi.Models;

namespace Project_FOA.Models
{
    public class Search
    {
        int idSearch;
        string searchKey;
        ITweet[] tweetsArray;  

        public Search(int idSearch, string searchKey, ITweet[] tweetsArray)
        {
            IdSearch = idSearch;
            SearchKey = searchKey;
            TweetsArray = tweetsArray;
        }

        public int IdSearch { get => idSearch; set => idSearch = value; }
        public string SearchKey { get => searchKey; set => searchKey = value; }
        public ITweet[] TweetsArray { get => tweetsArray; set => tweetsArray = value; }

        public Search() { }

        public List<Search> getSearch() //get search key words
        {
            DBservices dbs = new DBservices();
            List<Search> searchList = dbs.getSearch();
            return searchList;
        }
        
        public bool chkContains(string value) //check if the search key contains the help word
        {
            value = value.Replace("”", "");
            return this.searchKey.ToLower().Contains(value.ToLower());
        }
    }
}