﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_FOA.Models
{
    public class TweetersArrs
    {
        List<Tweeter> allNewTweeters;
        List<FriendsTweeter> allTweetersFriend;
        List<Tweeter> allTweetersToUpdate;

        public TweetersArrs(List<Tweeter> allNewTweeters, List<FriendsTweeter> allTweetersFriend, List<Tweeter> allTweetersToUpdate)
        {
            AllNewTweeters = allNewTweeters;
            AllTweetersFriend = allTweetersFriend;
            AllTweetersToUpdate = allTweetersToUpdate;
        }

        public List<Tweeter> AllNewTweeters { get => allNewTweeters; set => allNewTweeters = value; }
        public List<FriendsTweeter> AllTweetersFriend { get => allTweetersFriend; set => allTweetersFriend = value; }

        public List<Tweeter> AllTweetersToUpdate { get => allTweetersToUpdate; set => allTweetersToUpdate = value; }

        public TweetersArrs() { }
    }
}