﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Data;
using System.Text;
using Project_FOA.Models;
using System.Web.UI;
using System.Threading.Tasks;
using WebGrease.Css.Ast.Selectors;
using Tweetinvi.Models.Entities;
using System.Net.Configuration;

namespace Project_FOA.Models.DAL
{
    /// <summary>
    /// DBServices is a class created by me to provides some DataBase Services
    /// </summary>
    public class DBservices
    {
        public SqlDataAdapter da;
        public DataTable dt;

        public DBservices()
        {
        }

        //--------------------------------------------------------------------------------------------------
        // This method creates a connection to the database according to the connectionString name in the web.config 
        //--------------------------------------------------------------------------------------------------
        public SqlConnection connect(String conString)
        {

            // read the connection string from the configuration file
            string cStr = WebConfigurationManager.ConnectionStrings[conString].ConnectionString;
            SqlConnection con = new SqlConnection(cStr);
            con.Open();
            return con;
        }

        //--------------------------------------------------------------------------------------------------
        // This method inserts content to the content table 
        //--------------------------------------------------------------------------------------------------
        public void InsertContent(List<Content> contents)
        {

            SqlConnection con;
            SqlCommand cmd;

            try
            {
                con = connect("DBConnectionString"); // create the connection
            }
            catch (Exception ex)
            {
                // write to log
                throw new Exception("failed to connect to the server", ex);
            }

            foreach (var content in contents)
            {
                Content c = getTweetById(content.IdStrTweet, con);
                if (c == null) //new
                {
                    String cStr = BuildInsertContentCommand(content);      // helper method to build the insert string
                    cmd = CreateCommand(cStr, con);             // create the command 

                    try
                    {
                        int numEffected = cmd.ExecuteNonQuery(); // execute the command
                        if (numEffected == 0)
                            throw new Exception("could not insert all the contents");
                    }
                    catch (Exception ex)
                    {
                        // write to log
                        throw (ex);
                    }
                }
            }

            if (con != null)
            {
                con.Close();
            }
        }

        //--------------------------------------------------------------------
        // Build the Insert content command String
        //--------------------------------------------------------------------
        private String BuildInsertContentCommand(Content content)
        {
            String command;

            StringBuilder sb = new StringBuilder();
            // use a string builder to create the dynamic string
            sb.AppendFormat("Values('{0}', '{1}', '{2}', '{3}')", content.IdStrTweet, content.TextTweet, content.UrlTweet, content.IdStrUser);
            String prefix = "INSERT INTO TweetsContent_2021 " + "(idStrTweet, textTweet, urlTweet, idStrUser)";
            command = prefix + sb.ToString();

            return command;
        }

        //--------------------------------------------------------------------------------------------------
        // This method inserts friends of tweeter to the friendsOfTweeter_2021 table 
        //--------------------------------------------------------------------------------------------------
        public void InsertFriendsOfTweeter(List<FriendsTweeter> allTweetersFriends)
        {
            SqlConnection con;
            SqlCommand cmd;

            try
            {
                con = connect("DBConnectionString"); // create the connection
            }
            catch (Exception ex)
            {
                throw new Exception("failed to connect to the server", ex);
            }
            foreach (var item in allTweetersFriends)
            {
                bool combinationExists;
                if (!item.TweeterIsNew) //tweeter exists in db
                    combinationExists = getCombinationFriendWithTweeter(item.IdTweeter, item.IdFriendTweeter, con);
                else
                    combinationExists = false;
                if (item.TweeterIsNew == true || combinationExists == false)  // tweeter is new - so all his connections are new and need to be inserted, or tweeter exists but the combination not exists so we need to insert
                {
                    String cStr = BuildInsertFriendsOfTweeterCommand(item);      // helper method to build the insert string
                    cmd = CreateCommand(cStr, con);             // create the command 
                    try
                    {
                        int numEffected = cmd.ExecuteNonQuery(); // execute the command
                        if (numEffected == 0)
                            throw new Exception("could not insert all the combination");
                    }
                    catch (Exception ex)
                    {
                        throw (ex);
                    }
                }
            }
            if (con != null)
            {
                con.Close();
            }
        }

        //--------------------------------------------------------------------
        // Build the Insert friends of tweeter command String
        //--------------------------------------------------------------------
        private String BuildInsertFriendsOfTweeterCommand(FriendsTweeter ft)
        {
            String command;

            StringBuilder sb = new StringBuilder();
            // use a string builder to create the dynamic string
            sb.AppendFormat("Values('{0}', '{1}', {2})", ft.IdTweeter, ft.IdFriendTweeter, ft.SuspectedConnection);
            String prefix = "INSERT INTO friendsOfTweeters_2021 " + "(idTweeter, idFriendTweeter, suspectedConnection)";
            command = prefix + sb.ToString();

            return command;
        }

        //--------------------------------------------------------------------------------------------------
        // This method inserts tweeters array to the tweeters_train_2021 table 
        //--------------------------------------------------------------------------------------------------

        public void InsertTweetersArr(List<Tweeter> tweeters)
        {
            SqlConnection con;
            SqlCommand cmd;

            try
            {
                con = connect("DBConnectionString"); // create the connection
            }
            catch (Exception ex)
            {
                throw new Exception("failed to connect to the server", ex);
            }

            foreach (var tweeter in tweeters) // foreach tweeter in the array do the insert
            {
                String cStr = BuildInsertTweeterCommand(tweeter);      // helper method to build the insert string
                cmd = CreateCommand(cStr, con);             // create the command 
                try
                {
                    int numEffected = cmd.ExecuteNonQuery(); // execute the command
                    if (numEffected == 0)
                        throw new Exception("could not insert all the tweeters");
                }
                catch (Exception ex)
                {       
                    throw (ex);
                }
            }
            if (con != null)
            {
                con.Close();
            }
        }

        //--------------------------------------------------------------------
        // Build the Insert tweeter command String
        //--------------------------------------------------------------------
        private String BuildInsertTweeterCommand(Tweeter tweeter)
        {
            String command;

            StringBuilder sb = new StringBuilder();

            // use a string builder to create the dynamic string
            sb.AppendFormat(" Values('{0}', '{1}', {2},{3},'{4}',{5},{6},{7},{8},'{9}',{10})", tweeter.IdTweeter, tweeter.TweeterName, tweeter.FollowersCount, tweeter.FriendsCount, tweeter.TweeterCreatedAtAccount, tweeter.StatusesCountSinceCreated, tweeter.StatusesCountSinceChecked, tweeter.AntisemiticTweets, tweeter.AntisemiticFriends, tweeter.TweeterLocation, tweeter.IsAntisemitic);
            String prefix = "INSERT INTO Tweeters_train_2021 " + "(idTweeter,tweeterName, followersCount,friendsCount,tweeterCreatedAtAccount,statusesCountSinceCreated,statusesCountSinceChecked,antisemiticTweets,antisemiticFriends,tweeterLocation,isAntisemitic)";
            command = prefix + sb.ToString();

            return command;
        }

        //--------------------------------------------------------------------------------------------------
        // This method inserts tweets into table tweets_train_2021
        //--------------------------------------------------------------------------------------------------
        public void InsertTweets(List<Tweet> allTweets)
        {
            SqlConnection con;
            SqlCommand cmd;
            List<string> tweetersNotAntiToUpdate = new List<string>();//list of ids to update in db- statusesCountSinceChecked
            List<string> tweetersAntiToUpdate = new List<string>();      //list of ids to update in db - statusesCountSinceChecked +antisemiticTweets
            try
            {
                con = connect("DBConnectionString"); // create the connection
            }
            catch (Exception ex)
            {
                throw new Exception("failed to connect to the server", ex);
            }

            DBservices dbs2 = getProbwordsDT();

            foreach (var item in allTweets)
            {
                Tweet chkTweet = getChkTweetById(item.IdTweet, con);
                if (chkTweet == null)  // tweet is new
                {
                    int isAntisemitic = calc_NaiveBayes(item.TweetText, dbs2.dt);
                    String cStr = BuildInsertTweetsCommand(item, isAntisemitic);      // helper method to build the insert string
                    cmd = CreateCommand(cStr, con);             // create the command 
                    try
                    {
                        int numEffected = cmd.ExecuteNonQuery(); // execute the command
                        if (numEffected == 0)
                            throw new Exception("could not insert all the combination");
                    }
                    catch (SqlException ex)
                    {
                        if (ex.Number == 547)
                        { } 
                        else
                            throw (ex);
                    }

                    if (item.AttributedTweetersNames.Count > 0) //there are attributed tweeters
                    {
                        foreach (var item2 in item.AttributedTweetersNames)
                        {
                            string idAttributedTweeter = getTweeterByName(item2, con); //get the id of the attributed tweeter by his username
                       
                            cStr = BuildAttributesOfTweetsCommand(item.IdTweet, idAttributedTweeter); // insert into table attributesOfTweets_2021
                            cmd = CreateCommand(cStr, con);        // create the command 
                            try
                            {
                                int numEffected = cmd.ExecuteNonQuery(); // execute the command
                                if (numEffected == 0)
                                    throw new Exception("could not insert all the combination");
                            }
                            catch (SqlException ex)
                            {
                                if (ex.Number == 547)
                                { }
                                else
                                    throw (ex);
                            }
                        }
                    }
                    if (item.SearchId != -1) //we check bacause there is no hashtag exists for attributedTweetId (when searchId = -1 it means that we didn't found the tweeter by a search key)
                    {
                        insertTweetBySearch(item.IdTweet, item.SearchId, con);
                    }
                    if (isAntisemitic == 0)//create list of ids to update columns 
                    {
                        tweetersNotAntiToUpdate.Add(item.IdTweeter);
                    } 
                    else
                        tweetersAntiToUpdate.Add(item.IdTweeter);
                }                
                else // tweet is not new, we want to check if we found him with a new hashtag
                {
                    bool chkHashtagExist = getCheckIfCombinationTweetSearchExists(item.IdTweet, item.SearchId, con);//check if the combination of idsearch and idtweet exists already(table-tweetsBySearch)
                    if (chkHashtagExist == false & item.SearchId!=-1) //combination not exists, and it came from search(SearchId!=-1) 
                    {
                        insertTweetBySearch(item.IdTweet, item.SearchId, con);
                    }
                }
            }
            if (tweetersNotAntiToUpdate.Count > 0 | tweetersAntiToUpdate.Count > 0) //if at least one of them has values
            {
                DBservices dbs3 = getTweetersDT();
                dbs3.dt = updateTweetersAfterScoringTweets(dbs3.dt, tweetersNotAntiToUpdate, tweetersAntiToUpdate);
                dbs3.Update();
            }
            if (con != null)
            {
                con.Close();
            }
        }

        //check if the combination of idsearch and idtweet exists already(table-tweetsBySearch)
        private bool getCheckIfCombinationTweetSearchExists(string IdTweet, int SearchId, SqlConnection con)
        {
            String selectSTR = "select * from tweetsBySearch_2021 where idTweet = '" + IdTweet + "' and idSearch = " + SearchId;
            SqlCommand cmd = new SqlCommand(selectSTR, con);
            try
            {
                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end

                if (dr.Read())
                {  
                    return true;
                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        } 

        //insert into table tweetBySearch the combination of tweetId + searchId
        private void insertTweetBySearch(string IdTweet, int SearchId, SqlConnection con) {
            
           string cStr = BuildInsertTweetsBySearchCommand(IdTweet,SearchId);      // helper method to build the insert string         
            SqlCommand cmd = CreateCommand(cStr, con);             // create the command 
            try
            {
                int numEffected = cmd.ExecuteNonQuery(); // execute the command
                if (numEffected == 0)
                    throw new Exception("could not insert all the combination");
            }
            catch (SqlException ex)
            {
                if (ex.Number == 547)
                { }
                else
                    throw (ex);
            }
        }

        //____________________________________________________
        //update the tweeters that wrote anti and not anti tweets- statusesCountSinceChecked +antisemiticTweets
        //____________________________________________________-_
        private DataTable updateTweetersAfterScoringTweets(DataTable dt, List<string> tweetersNotAntiToUpdate,List<string> tweetersAntiToUpdate)
        {
            foreach (DataRow dr in dt.Rows)
            {
                foreach (var item in tweetersNotAntiToUpdate)
                {
                    if (item.Equals(dr["idTweeter"]))//search id in data table (tweeters-2021)
                    {
                        dr["statusesCountSinceChecked"] = Convert.ToInt32(dr["statusesCountSinceChecked"]) + 1;
                        break;                        
                    }
                }
                foreach (var item in tweetersAntiToUpdate)
                {
                    if (item.Equals(dr["idTweeter"]))
                    {
                        dr["statusesCountSinceChecked"] = Convert.ToInt32(dr["statusesCountSinceChecked"]) + 1;
                        dr["antisemiticTweets"] = Convert.ToInt32(dr["antisemiticTweets"]) + 1;                       
                    }
                }
            }
            return dt;
        }


        //--------------------------------------------------------------------
        // Build the Insert tweets command String
        //--------------------------------------------------------------------
        private String BuildInsertTweetsCommand(Tweet t,int isAntisemitic)
        {
            String command;

            StringBuilder sb = new StringBuilder();

            string prefix;

            if (t.AttributedTweetId == null) //the sql will insert the default value (null)
            {
                sb.AppendFormat("Values('{0}', '{1}', '{2}', {3}, {4}, {5},'{6}','{7}',{8},'{9}')", t.IdTweet, t.TweetCreatedAt, t.TweetText, t.QuoteCount, t.ReplyCount, t.RetweetCount, t.UrlTweet, t.TweetType, isAntisemitic, t.IdTweeter);
                prefix = "INSERT INTO tweets_train_2021 " + "(idTweet, tweetCreatedAt, tweetText, quoteCount, replyCount, retweetCount, urlTweet , tweetType, isAntisemitic, idTweeter )";
            }
            else
            {
                sb.AppendFormat("Values('{0}', '{1}', '{2}', {3}, {4}, {5},'{6}','{7}','{8}',{9},'{10}')", t.IdTweet, t.TweetCreatedAt, t.TweetText, t.QuoteCount, t.ReplyCount, t.RetweetCount, t.UrlTweet, t.TweetType, t.AttributedTweetId, isAntisemitic, t.IdTweeter);
                prefix = "INSERT INTO tweets_train_2021 " + "(idTweet, tweetCreatedAt, tweetText, quoteCount, replyCount, retweetCount, urlTweet , tweetType, attributedTweetId, isAntisemitic, idTweeter )";
            }
            command = prefix + sb.ToString();

            return command;
        }

        //--------------------------------------------------------------------
        // Build the Insert attributes of tweets command String
        //--------------------------------------------------------------------
        private String BuildAttributesOfTweetsCommand(string idTweet, string idAttributedTweeter)
        {
            String command;

            StringBuilder sb = new StringBuilder();
            // use a string builder to create the dynamic string
            sb.AppendFormat("Values('{0}', '{1}')", idTweet, idAttributedTweeter);
            String prefix = "INSERT INTO attributesOfTweets_2021 " + "(idTweet, idTweeter)";
            command = prefix + sb.ToString();

            return command;
        }

        //--------------------------------------------------------------------
        // Build the Insert tweets by search command String
        //--------------------------------------------------------------------
        private String BuildInsertTweetsBySearchCommand(string idTweet, int idSearch)
        {
            String command;

            StringBuilder sb = new StringBuilder();
            // use a string builder to create the dynamic string
            sb.AppendFormat("Values({0}, '{1}')", idSearch, idTweet);
            String prefix = "INSERT INTO tweetsBySearch_2021 " + "(idSearch , idTweet)";
            command = prefix + sb.ToString();

            return command;
        }

        //---------------------------------------------------------------------------------
        // Create the SqlCommand
        //---------------------------------------------------------------------------------
        private SqlCommand CreateCommand(String CommandSTR, SqlConnection con)
        {

            SqlCommand cmd = new SqlCommand(); // create the command object

            cmd.Connection = con;              // assign the connection to the command object

            cmd.CommandText = CommandSTR;      // can be Select, Insert, Update, Delete 

            cmd.CommandTimeout = 10;           // Time to wait for the execution' The default is 30 seconds

            cmd.CommandType = System.Data.CommandType.Text; // the type of the command, can also be stored procedure

            return cmd;
        }

        //data reader check if tweet exists by id 
        public Tweet getChkTweetById(string idTweet, SqlConnection con)
        {

            String selectSTR = "SELECT * FROM tweets_train_2021 where idTweet = '" + idTweet + "'";
            SqlCommand cmd = new SqlCommand(selectSTR, con);

            try
            {
                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end

                if (dr.Read())
                {   // Read till the end of the data into a row
                    Tweet t = new Tweet();

                    t.IdTweet = (string)dr["idTweet"];
                    t.TweetCreatedAt = (string)dr["tweetCreatedAt"];
                    t.TweetText = (string)dr["tweetText"];
                    t.QuoteCount = Convert.ToInt32(dr["quoteCount"]);
                    t.ReplyCount = Convert.ToInt32(dr["replyCount"]);
                    t.RetweetCount = Convert.ToInt32(dr["retweetCount"]);
                    t.UrlTweet = (string)dr["urlTweet"];
                    t.TweetType = (string)dr["tweetType"];
                    t.AttributedTweetId = (dr["attributedTweetId"] != DBNull.Value) ? (string)dr["attributedTweetId"] : "";
                    t.IsAntisemitic = Convert.ToInt32(dr["isAntisemitic"]);
                    t.IdTweeter = (string)dr["idTweeter"];

                    return t;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        //data reader check if tweeter exists by username
        public string getTweeterByName(string tweeterName, SqlConnection con)
        {
            String selectSTR = "SELECT idTweeter FROM Tweeters_train_2021 where tweeterName = '" + tweeterName + "'";
            SqlCommand cmd = new SqlCommand(selectSTR, con);
            try
            {
                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end

                if (dr.Read())
                {  
                    string idTweeter = (string)dr["idTweeter"];
                    return idTweeter;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        //data reader check if tweet exists in content table by id (for python)
        public Content getTweetById(string idStrTweet, SqlConnection con)
        {
            String selectSTR = "SELECT * FROM TweetsContent_2021 where idStrTweet = '" + idStrTweet + "'";
            SqlCommand cmd = new SqlCommand(selectSTR, con); 
            try
            {
                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end

                if (dr.Read())
                {   // Read till the end of the data into a row
                    Content c = new Content();

                    c.IdStrTweet = (string)dr["idStrTweet"];
                    c.TextTweet = (string)dr["textTweet"];
                    c.UrlTweet = (string)dr["urlTweet"];
                    c.IdStrUser = (string)dr["idStrUser"];
             
                    return c;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw (ex);
            }

        }

        //data reader check if combination of tweeter and a friend exists
        public bool getCombinationFriendWithTweeter(string idTweeter, string idFriendTweeter, SqlConnection con)
        {
            SqlCommand cmd;
            try
            {
                String selectSTR = "select * from friendsOfTweeters_2021 where idTweeter = '" + idTweeter + "' and idFriendTweeter = '"+ idFriendTweeter + "'" ;
                 cmd = new SqlCommand(selectSTR, con);
          
                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end

                if (dr.Read())
                {   
                    return true; //read - combination exists!
                }
                else
                    return false;

            }
            catch (Exception ex)
            {
                // write to log
                throw (ex);
            }
        }

        //data reader check if tweeter exists
        public Tweeter getTweeterById(string idTweeter)
        {
            SqlConnection con = null;

            try
                {
                 con = connect("DBConnectionString"); // create a connection to the database using the connection String defined in the web config file
                }
           catch (Exception ex)
                {
                  throw (ex);
                }
            try
            {
                String selectSTR = "select * from Tweeters_train_2021 where idTweeter = '" + idTweeter + "'";
                SqlCommand cmd = new SqlCommand(selectSTR, con);

                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end

                if (dr.Read())
                {   
                    Tweeter t = new Tweeter();

                    t.IdTweeter = (string)dr["idTweeter"]; ;
                    t.TweeterName = (string)dr["tweeterName"];
                    t.FollowersCount = Convert.ToInt32(dr["followersCount"]);
                    t.FriendsCount = Convert.ToInt32(dr["friendsCount"]);
                    t.TweeterCreatedAtAccount = (string)dr["tweeterCreatedAtAccount"];
                    t.StatusesCountSinceCreated = Convert.ToInt32(dr["statusesCountSinceCreated"]);
                    t.StatusesCountSinceChecked = Convert.ToInt32(dr["statusesCountSinceChecked"]);
                    t.AntisemiticTweets = Convert.ToInt32(dr["antisemiticTweets"]);
                    t.AntisemiticFriends = Convert.ToInt32(dr["antisemiticFriends"]);
                    t.TweeterLocation = (string)dr["tweeterLocation"];
                    t.IsAntisemitic = Convert.ToInt32(dr["isAntisemitic"]);

                    return t;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally {
                if (con != null)
                    con.Close();
            }
        }

        //data reader check if tweeter is antisemitic by id
        public Tweeter getAntisemiticTweeterById(string idTweeter)
        {
            SqlConnection con = null;
                try
                {
                    con = connect("DBConnectionString"); // create a connection to the database using the connection String defined in the web config file
                }
                catch (Exception ex)
                {
                    throw (ex);
                }
            try
               {
                String selectSTR = "select* from Tweeters_train_2021 where isAntisemitic = 1 and idTweeter = '" + idTweeter + "'";
                SqlCommand cmd = new SqlCommand(selectSTR, con);

                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end

                if (dr.Read())
                { 
                    Tweeter t = new Tweeter();

                    t.IdTweeter = (string)dr["idTweeter"];;
                    t.TweeterName = (string)dr["tweeterName"];
                    t.FollowersCount = Convert.ToInt32(dr["followersCount"]);
                    t.FriendsCount = Convert.ToInt32(dr["friendsCount"]);
                    t.TweeterCreatedAtAccount = (string)dr["tweeterCreatedAtAccount"];
                    t.StatusesCountSinceCreated = Convert.ToInt32(dr["statusesCountSinceCreated"]);
                    t.StatusesCountSinceChecked = Convert.ToInt32(dr["statusesCountSinceChecked"]);
                    t.AntisemiticTweets = Convert.ToInt32(dr["antisemiticTweets"]);
                    t.AntisemiticFriends = Convert.ToInt32(dr["antisemiticFriends"]);
                    t.TweeterLocation = (string)dr["tweeterLocation"];
                    t.IsAntisemitic = Convert.ToInt32(dr["isAntisemitic"]);

                    return t;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
                {
                if (con != null)
                    con.Close();
               }
        }

        //data reader all ngrams
        public List<Search> getSearch()
        {
            SqlConnection con = null;
            List<Search> searchList = new List<Search>();

            try
            {
                con = connect("DBConnectionString"); // create a connection to the database using the connection String defined in the web config file

                String selectSTR = "SELECT * FROM search_2021";
                SqlCommand cmd = new SqlCommand(selectSTR, con);

                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end

                while (dr.Read())
                {   // Read till the end of the data into a row
                    Search s = new Search();
                    s.IdSearch = Convert.ToInt32(dr["idSearch"]);
                    s.SearchKey = (string)dr["searchKey"];

                    searchList.Add(s);
                }

                return searchList;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
        }

        //data reader all help key words
        public List<HelpKeyWord> getHelpKeyWords()
        {
            SqlConnection con = null;
            List<HelpKeyWord> helpKeyWordsList = new List<HelpKeyWord>();

            try
            {
                con = connect("DBConnectionString"); // create a connection to the database using the connection String defined in the web config file

                String selectSTR = "SELECT * FROM helpKeyWords_2021";
                SqlCommand cmd = new SqlCommand(selectSTR, con);

                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end

                while (dr.Read())
                {   // Read till the end of the data into a row
                    HelpKeyWord h = new HelpKeyWord();
                    h.IdHelpKey = Convert.ToInt32(dr["idHelpKey"]);
                    h.KeyWord = (string)dr["keyWord"];

                    helpKeyWordsList.Add(h);
                }
                return helpKeyWordsList;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
        }

        //update tweeter
        public void UpdateTweeter(List<Tweeter> AllTweetersToUpdate)
        {
            SqlConnection con;
            SqlCommand cmd;

            try
            {
                con = connect("DBConnectionString"); // create a connection to the database using the connection String defined in the web config file
            }
            catch (Exception ex)
            {
                throw new Exception("failed to connect to the server", ex);
            }
            foreach (var tweeter in AllTweetersToUpdate)
            {
             String selectSTR = "update Tweeters_train_2021 set[followersCount] = "+ tweeter.FollowersCount;
             selectSTR += ",[friendsCount] ="+ tweeter.FriendsCount + " ,[statusesCountSinceCreated] = "+ tweeter.StatusesCountSinceCreated ;
             selectSTR += ",[antisemiticFriends]="+tweeter.AntisemiticFriends +",[tweeterLocation]= '"+ tweeter.TweeterLocation +"'";
             selectSTR += " where idTweeter = '" +tweeter.IdTweeter+"'";

             cmd = CreateCommand(selectSTR, con);
            try
            {
                int numEffected = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            }
            if (con != null)
             {
              con.Close();
             }
        }

        //---------------------------------------------------------------------------------

        // Data set
        //---------------------------------------------------------------------------------

        //data set to get all the information about the tweeter - from Tweeters_train_2021
        public DBservices getTweetersDT()
        {
            SqlConnection con = null;

            try
            {
                // connect
                con = connect("DBConnectionString");
                // create a dataadaptor
                da = new SqlDataAdapter("select * from Tweeters_train_2021", con);
                // automatic build the commands
                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                // create a DataSet
                DataSet ds = new DataSet();
                // Fill the Dataset
                da.Fill(ds);
                // keep the table in a field
                dt = ds.Tables[0];
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                if (con != null)
                    con.Close();
            }
            return this;
        }

        //data set to get all the information about probability of words from NaiveBayes_2021
        public DBservices getProbwordsDT()
        {
            SqlConnection con = null;
            try
            {
                // connect
                con = connect("DBConnectionString");
                // create a dataadaptor
                da = new SqlDataAdapter("select * from NaiveBayes_2021", con); 
                // automatic build the commands
                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                // create a DataSet
                DataSet ds = new DataSet();
                // Fill the Dataset
                da.Fill(ds);
                // keep the table in a field
                dt = ds.Tables[0];
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                if (con != null)
                    con.Close();
            }
            return this;
        }
        //--------------------------------------------------------------------------------------------------

        public int calc_NaiveBayes(String tweetsText, DataTable dt) //algorithm to calculate the anitsemitism of tweet (if it's antisemitic or not)
        {
            string word;
            //float pWord; -- we will use it later for further calculations (the decision won't be binary) - denominator
            double pWordWithAnti;
            double pWordWithNotAnti; 
            double CalcprobAnti=1;
            double CalcprobNotAnti=1;
            double PAnti = 0.3784255362824592;
            double PNnotAnti = 0.6215744637175408;
           
            tweetsText.ToLower();            
            var arrWords = tweetsText.Split(' ');
            foreach (var item in arrWords)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    word = (string)dr["word"];
                    if (item==word)
                    {
                        pWordWithAnti = (float)Convert.ToDouble(dr["pWordWithAnti"]);
                        CalcprobAnti = CalcprobAnti * pWordWithAnti;
                        pWordWithNotAnti = (float)Convert.ToDouble(dr["pWordWithNotAnti"]);
                        CalcprobNotAnti = CalcprobNotAnti * pWordWithNotAnti;
                        break;
                    }
                }
            } 
            CalcprobAnti = CalcprobAnti * PAnti; //numerator of bayes - antisemitic
            CalcprobNotAnti = CalcprobNotAnti * PNnotAnti; // numerator of bayes - not antisemitic
            if (CalcprobAnti> CalcprobNotAnti) 
            {
                return 1; //text is antisemitic
            }
            else
            {
                return 0; //text is not anti
            }
        }
        //data reader get all tweets for the volunteer
        public List<Tweet> getTweets(int idUser)
        {
            SqlConnection con = null;
            List<Tweet> TweetsList = new List<Tweet>();
            try
            {
                con = connect("DBConnectionString");

                //String selectSTR = "select * from tweets_train_2021 where isAntisemitic = 1 and tweetType != 'retweet' and idTweet not in (select idTweet from reports_2021 where idUser = " + idUser + " or idTweet in (select cntByIdTweet.idTweet ";
                //selectSTR = " from (select b.idTweet, COUNT(r.idReport) as cntIdReport from reports_2021 r right join tweets_train_2021 b on r.idTweet = b.idTweet group by b.idTweet having COUNT(idReport) > 5) cntByIdTweet))";

                string selectSTR = "select * from tweets_train_2021 where isAntisemitic = 1 and tweetType != 'retweet' and idTweet not in (select idTweet from reports_2021 where idUser = " + idUser + " or idTweet in (select cntByIdTweet.idTweet from (select b.idTweet, COUNT(r.idReport) as cntIdReport from reports_2021 r right join tweets_train_2021 b on r.idTweet = b.idTweet group by b.idTweet having COUNT(idReport) > 5) cntByIdTweet))";
                
                SqlCommand cmd = new SqlCommand(selectSTR, con);
                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end
                while (dr.Read())
                {   // Read till the end of the data into a row
                    Tweet t = new Tweet();
                    t.IdTweet = (string)dr["idTweet"];
                    t.TweetText = (string)dr["tweetText"];
                    t.UrlTweet = (string)dr["urlTweet"];                  
                    t.IsAntisemitic = Convert.ToInt32(dr["isAntisemitic"]);
             
                    TweetsList.Add(t);
                }
                return TweetsList;
            } 
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
        }

        //data reader get all Decisions for the volunteer page
        public List<Decision> getDecisions()
        {
            SqlConnection con = null;
            List<Decision> DecisionsList = new List<Decision>();

            try
            {
                con = connect("DBConnectionString"); // create a connection to the database using the connection String defined in the web config file

                String selectSTR = "select * from decisions_2021";
                SqlCommand cmd = new SqlCommand(selectSTR, con);
                // get a reader
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection); // CommandBehavior.CloseConnection: the connection will be closed after reading has reached the end

                while (dr.Read())
                {   // Read till the end of the data into a row
                    Decision d = new Decision();
                    d.IdDecision = Convert.ToInt32(dr["idDecision"]);
                    d.Reason = (string)dr["reason"];
                    d.DecisionBit = Convert.ToInt32(dr["decision"]);
                    DecisionsList.Add(d);
                }
                return DecisionsList;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }
        }

        //--------------------------------------------------------------------------------------------------
        // This method insert report to the report table 
        //--------------------------------------------------------------------------------------------------
        public int InsertReports(Report reportObj)
        {
            SqlConnection con;
            SqlCommand cmd;
            try
            {
                con = connect("DBConnectionString"); // create the connection
            }
            catch (Exception ex)
            {
                throw new Exception("failed to connect to the server", ex);
            }

             String cStr = BuildInsertReportCommand(reportObj);      // helper method to build the insert string
             cmd = CreateCommand(cStr, con);             // create the command 
            try
            {
                int idReport = Convert.ToInt32(cmd.ExecuteScalar());
                return idReport;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally {
                if (con != null)
                {
                    con.Close();
                }
            }
        }

        //--------------------------------------------------------------------
        // Build the Insert report command String
        //--------------------------------------------------------------------
        private String BuildInsertReportCommand(Report reportObj)
        {
            String command;

            StringBuilder sb = new StringBuilder();
            sb.AppendFormat(" Values ({0}, '{1}', {2})", reportObj.Iduser, reportObj.Idtweet, reportObj.Idecision);
            String prefix = "INSERT INTO  reports_2021 " + "(idUser, idTweet, idDecision)";
            command = prefix + sb.ToString() + " select SCOPE_IDENTITY()";

            return command;
        }

        //-------------------------------------------------------------------
        //data set
        //-------------------------------------------------------------------
        public void Update()
        {
            da.Update(dt);
        }
    }
}


