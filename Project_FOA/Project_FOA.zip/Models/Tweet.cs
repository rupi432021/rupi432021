﻿using Project_FOA.Models.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_FOA.Models
{
    public class Tweet 
    {
        string idTweet;
        string tweetCreatedAt;
        string tweetText;
        int quoteCount;
        int replyCount;
        int retweetCount;
        string urlTweet;
        string tweetType;
        string attributedTweetId;
        int isAntisemitic;
        string idTweeter;
        List<string> attributedTweetersNames; // we have table attributesOfTweets (many to many)
        int searchId; // we have table tweetsBySearch (many to many)

        public Tweet(string idTweet, string tweetCreatedAt, string tweetText, int quoteCount, int replyCount, int retweetCount, string urlTweet, string tweetType, string attributedTweetId, int isAntisemitic, string idTweeter, List<string> attributedTweetersNames, int searchId)
        {
            IdTweet = idTweet;
            TweetCreatedAt = tweetCreatedAt;
            TweetText = tweetText;
            QuoteCount = quoteCount;
            ReplyCount = replyCount;
            RetweetCount = retweetCount;
            UrlTweet = urlTweet;
            TweetType = tweetType;
            AttributedTweetId = attributedTweetId;
            IsAntisemitic = isAntisemitic;
            IdTweeter = idTweeter;
            AttributedTweetersNames = attributedTweetersNames;
            SearchId = searchId;
        } 
        public string IdTweet { get => idTweet; set => idTweet = value; }
        public string TweetCreatedAt { get => tweetCreatedAt; set => tweetCreatedAt = value; }
        public int QuoteCount { get => quoteCount; set => quoteCount = value; }
        public int ReplyCount { get => replyCount; set => replyCount = value; }
        public int RetweetCount { get => retweetCount; set => retweetCount = value; }
        public string UrlTweet { get => urlTweet; set => urlTweet = value; }
        public string TweetType { get => tweetType; set => tweetType = value; }
        public string AttributedTweetId { get => attributedTweetId; set => attributedTweetId = value; }
        public int IsAntisemitic { get => isAntisemitic; set => isAntisemitic = value; }
        public List<string> AttributedTweetersNames { get => attributedTweetersNames; set => attributedTweetersNames = value; }
        public string TweetText { get => tweetText; set => tweetText = value; }
        public int SearchId { get => searchId; set => searchId = value; }
        public string IdTweeter { get => idTweeter; set => idTweeter = value; }

        public Tweet() { }

        public void InsertTweets(List<Tweet> allTweets) //insert tweets
        {
            DBservices dbs = new DBservices();
            dbs.InsertTweets(allTweets);
        }
        public List<Tweet> getTweets(int idUser) //get all tweets for the volunteer page
        {
            DBservices dbs = new DBservices();
            List<Tweet> TweetsList = dbs.getTweets(idUser);
            return TweetsList;
        }
    }
}