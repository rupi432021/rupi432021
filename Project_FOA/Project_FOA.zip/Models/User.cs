﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_FOA.Models
{
    public class User
    {
        int iduser;
        string userName;
        string userPassword;
        string firstName;
        string lastName;
        string email;
        string phone;

        public User(int iduser, string userName, string userPassword, string firstName, string lastName, string email, string phone)
        {
            Iduser = iduser;
            UserName = userName;
            UserPassword = userPassword;
            FirstName = firstName;
            LastName = lastName;
            Email = email;
            Phone = phone;
        }

        public int Iduser { get => iduser; set => iduser = value; }
        public string UserName { get => userName; set => userName = value; }
        public string UserPassword { get => userPassword; set => userPassword = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string Email { get => email; set => email = value; }
        public string Phone { get => phone; set => phone = value; }
    }
}

