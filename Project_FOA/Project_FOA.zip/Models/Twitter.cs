﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using Tweetinvi;
using Tweetinvi.Parameters;
using Tweetinvi.Models;
using Tweetinvi.Parameters.Enum;
using Tweetinvi.Parameters.V2;
using System.Security.Policy;
using Project_FOA.Models.DAL;
using Microsoft.Ajax.Utilities;
using Tweetinvi.Exceptions;
using Tweetinvi.Core.Models;
using System.Data;

namespace Project_FOA.Models
{
    public class Twitter
    {
        //old tokens!!! 
        //const string apiKey = "rtAam1dOD4Cg3NOO272BgOuCI";
        //const string apiKeySecret = "qlnGvuzOVDwLtbB0zvNOQwL34hfXrSd3bxJkzlGBSTZrVIgJ10";
        //const string accessToken = "1348717792258891789-KHqssfuxrjyTIYJ7sMStc7AAJvhNla";
        //const string accessTokenSecret = "bjlznhJV9ClefxphjC5BzrcNLicIIRTxmfVZsI2ZUR84d";

        //new tokens!!!
        const string apiKey = "XhU15jfU4AysmqxI9KnZ1iRzO";
        const string apiKeySecret = "goZYjm8weo5KlGVt99buVT9y02qOXoUH7lh4q9CBNfqaxVxPhK";
        const string accessToken = "1377561861114200064-VoFL2mMXKxhz9R9f48xgIQxTrqj8zQ";
        const string accessTokenSecret = "7xUDX4w5AqSKlL40VQ6cndueWSgPiF1flC0gYX1t4TckR";

        public Twitter() { }

        public async Task<object> test() //get tweets from twitter by search key words
        {
            Search s = new Search();
            HelpKeyWord h = new HelpKeyWord();
            List<Search> searchList = s.getSearch(); 
            List<HelpKeyWord> helpKeyWordsList = h.getHelpKeyWords();
            List<Object> allTweets = new List<object>();

            var tc = new TwitterClient(apiKey, apiKeySecret, accessToken, accessTokenSecret);

            string str = "";

            foreach (var item in searchList)
            {
                foreach (var item2 in helpKeyWordsList) // the first help key word is "" so we can search the keySearch alone 
                {
                    if ((!item.chkContains(item2.KeyWord)) | (item2.KeyWord == "")) // if the search key contains the help word we don't need their combination
                    {
                        str = item.SearchKey + " " + item2.KeyWord;

                        var parameters = new SearchTweetsParameters(str)
                        {
                            Filters = TweetSearchFilters.Hashtags,
                            Lang = LanguageFilter.English
                        };

                        var tweets = await tc.Search.SearchTweetsAsync(parameters);

                        Search tweetsBySearch = new Search(item.IdSearch, item.SearchKey, tweets);

                        allTweets.Add(tweetsBySearch);
                    }
                }
            }   
            return allTweets;
        }

        //get the tweeters information - including the calculation of : antisemitic tweets, antisemitic friends, etc
        public async Task<TweetersArrs> getTweetersInfo(List<Tweeter> tweetersArr)
        {
            var tc = new TwitterClient(apiKey, apiKeySecret, accessToken, accessTokenSecret); 

            List<FriendsTweeter> allTweetersFriends = new List<FriendsTweeter>(); //consists the friends (that exist in the db) list of every tweeter
            List<Tweeter> allNewTweeters = new List<Tweeter>(); //consists all new tweeters that we need to insert together into table tweeters_train_2021
            List<Tweeter> allTweetersToUpdate = new List<Tweeter>(); //consists all tweeters that exist in the db and we need to update them
            DBservices dbs = new DBservices(); 

            // enable track and await - because of rate limit
            tc.Config.RateLimitTrackerMode = RateLimitTrackerMode.TrackAndAwait;
            
            List<Tweeter> tList = new List<Tweeter>(); //list of tweeters that exists in the db
            dbs = dbs.getTweetersDT(); // using data table
            
            //check if tweeter exists in data table(from data set)
            foreach (DataRow dr in dbs.dt.Rows)
            {
                Tweeter t = new Tweeter();
          
                t.IdTweeter = (string)dr["idTweeter"]; ;
                t.TweeterName = (string)dr["tweeterName"];
                t.FollowersCount = Convert.ToInt32(dr["followersCount"]);
                t.FriendsCount = Convert.ToInt32(dr["friendsCount"]);
                t.TweeterCreatedAtAccount = (string)dr["tweeterCreatedAtAccount"];
                t.StatusesCountSinceCreated = Convert.ToInt32(dr["statusesCountSinceCreated"]);
                t.StatusesCountSinceChecked = Convert.ToInt32(dr["statusesCountSinceChecked"]);
                t.AntisemiticTweets = Convert.ToInt32(dr["antisemiticTweets"]);
                t.AntisemiticFriends = Convert.ToInt32(dr["antisemiticFriends"]);
                t.TweeterLocation = (string)dr["tweeterLocation"];
                t.IsAntisemitic = Convert.ToInt32(dr["isAntisemitic"]);
                tList.Add(t);
            }
           
            for (int i = 0; i < tweetersArr.Count; i++)
            {
                //check if tweeter exists
                Tweeter t = null;
                int antisemiticTweeter = 0;
                foreach (var tweeterObj in tList) 
                {
                    if (tweetersArr[i].IdTweeter == tweeterObj.IdTweeter) //if it exists
                    {
                        t = tweeterObj; //tweeter object
                        antisemiticTweeter = tweeterObj.IsAntisemitic; //tweeter is antisemitic (yes\no)
                        break;
                    }                   
                }               
                try
                {          
                    var friendIds = await tc.Users.GetFriendIdsAsync(tweetersArr[i].TweeterName); //all friends ids of tweeter
                    int cntAntisemiticFriends = 0;                    

                    for (int j = 0; j < friendIds.Length; j++)  // 1. count antisemitic friends 2. connection with friend (suspected or not)
                    { 
                        string friendId = friendIds[j].ToString();                                                       
                        int antisemiticFriendTweeter = 0;
                        foreach (var tweeterObj in tList)
                        {
                            if (friendId == tweeterObj.IdTweeter)  //check if friend exists in db
                            {                    
                                antisemiticFriendTweeter = tweeterObj.IsAntisemitic; //friend tweeter is anitsemitic (yes\no)
                                if (antisemiticFriendTweeter != 0) // friend is antisemitic
                                    cntAntisemiticFriends++;

                                FriendsTweeter ft = new FriendsTweeter();//object to insert into friendsOfTweeters_2021 table

                                if (t != null) // tweeter exists
                                {
                                    if (antisemiticTweeter != 0 || antisemiticFriendTweeter != 0) // tweeter is antisemitic or friend antisemitic 
                                        ft = new FriendsTweeter(tweetersArr[i].IdTweeter, friendId, 1, false);//connection is suspected
                                    else // tweeter exists but not antisemitic, and friend exists but not antismeitic
                                        ft = new FriendsTweeter(tweetersArr[i].IdTweeter, friendId, 0, false); //connection is not suspected
                                }
                                else // tweeter is new 
                                {
                                    if (antisemiticFriendTweeter != 0) // tweeter is new, friend is antisemitic
                                        ft = new FriendsTweeter(tweetersArr[i].IdTweeter, friendId, 1, true);
                                    else // tweeter is new, friend is not antisemitic
                                        ft = new FriendsTweeter(tweetersArr[i].IdTweeter, friendId, 0, true);//later when we make a decision about the new tweeter - if we decide that he is anti-Semitic then the connection is suspected
                                }
                                allTweetersFriends.Add(ft);
                                break; 
                            }
                        }
                    }

                    tweetersArr[i].FriendsCount = friendIds.Length;
                    tweetersArr[i].AntisemiticFriends = cntAntisemiticFriends;

                    if (t == null) // tweeter is new 
                        allNewTweeters.Add(tweetersArr[i]); //add the new tweeter into the array of all new tweeters
                    else // tweeter exists
                    {
                        allTweetersToUpdate.Add(tweetersArr[i]);
                        //update some fields of tweeter - friendsCount, followersCount.. 
                    }
                }
                catch (TwitterException ex)
                {
 
                }
            }
            
            TweetersArrs ta = new TweetersArrs(allNewTweeters, allTweetersFriends, allTweetersToUpdate);
            return ta;
        }

        ////get tweeter information from twitter
        //public async Task<List<Tweeter>> getTweeter(string tweetersToExplore)
        //{
        //    var tc = new TwitterClient(apiKey, apiKeySecret, accessToken, accessTokenSecret);

        //    var tweetersArray = tweetersToExplore.Split(',');

        //    List<Tweeter> allUsers = new List<Tweeter>();

        //    // enable track and await - because of rate limit
        //    tc.Config.RateLimitTrackerMode = RateLimitTrackerMode.TrackAndAwait;

        //    foreach (var item in tweetersArray)
        //    {
        //        try
        //        {
        //            var userResponse = await tc.UsersV2.GetUserByNameAsync(item);
        //            var user = userResponse.User;
        //            if (user != null) // it can be null if the user is suspended in twitter
        //            {
        //                Tweeter tweeter = new Tweeter(user.Id, user.Username, user.PublicMetrics.FollowersCount, 0, user.CreatedAt.ToString(), user.PublicMetrics.TweetCount, 0, 0, 0, user.Location, 0, null);
        //                allUsers.Add(tweeter);
        //            }
        //        }
        //        catch (TwitterException e)
        //        {

        //        }
        //    }
        //    return allUsers ;
        //}



        public async Task<Tweeter> getTweeter(string tweeterToExplore)
        {
            var tc = new TwitterClient(apiKey, apiKeySecret, accessToken, accessTokenSecret);

     

            // enable track and await - because of rate limit
            tc.Config.RateLimitTrackerMode = RateLimitTrackerMode.TrackAndAwait;
            Tweeter tweeter = new Tweeter();
            try
            {
                var userResponse = await tc.UsersV2.GetUserByNameAsync(tweeterToExplore);
                var user = userResponse.User;
                tweeter = new Tweeter(user.Id, user.Username, user.PublicMetrics.FollowersCount, 0, user.CreatedAt.ToString(), user.PublicMetrics.TweetCount, 0, 0, 0, user.Location, 0, null);
            
            }
       
                catch (TwitterException e)
                {

                }


            return tweeter;
        }



        //get tweets information from twitter by id - and get the information about their tweeters too
        public async Task<List<ExpendedTweet>> getTweets(string tweetsToExplore)
        {
            var tc = new TwitterClient(apiKey, apiKeySecret, accessToken, accessTokenSecret);

            var str = tweetsToExplore.Split(',');

            List<ExpendedTweet> AllExpendedTweets = new List<ExpendedTweet>();
            
            foreach (var item in str)
            {
                var tweetResponse = await tc.TweetsV2.GetTweetAsync(item);
                var tweetApi = tweetResponse.Tweet;
                if (tweetApi != null) //the tweet is not removed from twitter
                {
                    var tweetAuthor = tweetResponse.Includes.Users[0]; //include information about the tweeter of the tweet

                    string urlTweet = "https://twitter.com/" + tweetAuthor.Username + "/status/" + tweetApi.Id;
                    string tweetType = "";
                    string attributedTweetId = null;
                   
                    if (tweetApi.ReferencedTweets == null)
                        tweetType = "ordinary";
                    else
                    {
                        attributedTweetId = tweetApi.ReferencedTweets[0].Id;
                        switch (tweetApi.ReferencedTweets[0].Type)
                        {
                            case "quoted":
                                tweetType = "quote";
                                break;
                            case "replied_to":
                                tweetType = "reply";
                                break;
                            default:
                                tweetType = "retweeted";
                                break;
                        }
                    }

                    List<string> attributedTweetersNames = new List<string>(); //user mentions 
                    List<string> hashtags = new List<string>(); //hashtags to explore later

                    if (tweetApi.Entities != null)
                    {
                        if (tweetApi.Entities.Mentions != null) // there are user mentions
                        {
                            for (int i = 0; i < tweetApi.Entities.Mentions.Length; i++)
                            {
                                attributedTweetersNames.Add(tweetApi.Entities.Mentions[i].Username);
                            }
                        }
                        if (tweetApi.Entities.Hashtags != null) // there are hashtags
                        {
                            for (int i = 0; i < tweetApi.Entities.Hashtags.Length; i++)
                            {
                                hashtags.Add(tweetApi.Entities.Hashtags[i].Tag);
                            }
                        }
                    }
                    Tweeter tweeter = new Tweeter(tweetAuthor.Id, tweetAuthor.Username, tweetAuthor.PublicMetrics.FollowersCount, 0, tweetAuthor.CreatedAt.ToString(), tweetAuthor.PublicMetrics.TweetCount, 0, 0, 0, tweetAuthor.Location, 0, null);
                    ExpendedTweet et = new ExpendedTweet(tweetApi.Id, tweetApi.CreatedAt.ToString(), tweetApi.Text, tweetApi.PublicMetrics.QuoteCount, tweetApi.PublicMetrics.ReplyCount, tweetApi.PublicMetrics.RetweetCount, urlTweet, tweetType, attributedTweetId, 0, tweetAuthor.Id, attributedTweetersNames, -1, tweeter, hashtags);                  
                    AllExpendedTweets.Add(et);
                }
            }
            return AllExpendedTweets;
        }

    }
}